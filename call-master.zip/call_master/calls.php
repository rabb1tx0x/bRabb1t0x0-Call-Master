<?php

require_once 'vender/autoload.php';

use Twilio\Rest\Client;

$AccountSID = $_ENV['TWILIO_ACCOUNT_SID'];
$AuthToken  = $_ENV['TWILIO_AUTH_TOKEN'];

$client = new Client($AccountSID, $AuthToken);

try {

	$call = $client->calls->create(

		'+152xxxxxxxx', // Phone number to call
		'+12xxxxxxxxx', // twilio phone number
		array("url" => 'http://demo.twilio.com/docs/voice.xml')

	);

	echo "Phone Call has just Started: ".$call->sid;
	
} catch (Exception $e) {
	
	echo  "Error: ".$e->getMessage();
}

?>